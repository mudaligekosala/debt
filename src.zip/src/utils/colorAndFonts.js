//colors
export const color_primary = '#42a5f5';
export const btn_color = '#0077c2';
export const color_primary_light = '#80d6ff';
export const color_primary_text = '#000000';
//fonts
export const text_size_large = 30;
export const btn_text_size = 20;

