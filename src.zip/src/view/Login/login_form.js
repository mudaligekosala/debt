import React, { Component } from 'react';
import { StyleSheet, View, TextInput, TouchableOpacity, Text } from 'react-native';
//styles
import { btn_color,btn_text_size } from '../../utils/colorAndFonts';

const LoginForm = () => {
    return (
        <View style={styles.container}>
            <TextInput
                style={styles.txt_in_username}
                placeholder={'username'}
            />
            <TextInput
                style={styles.txt_in_password}
                placeholder={'password'}
            />
            <TouchableOpacity
                style={styles.btn_login}
            >
                <Text
                    style={styles.txt_login}
                >Login</Text>
            </TouchableOpacity>
        </View>
    )
}

const styles= StyleSheet.create({
    container:{
        backgroundColor:'yellow',
        alignItems: 'center',
        margin:30,
        padding:20,
        justifyContent:'space-between',
       flex: 1,
    },
    txt_in_username:{
        width:'100%',
        borderWidth: 1,
        borderRadius: 100,
      
    },
    txt_in_password:{
        width:'100%',
        borderWidth: 1,
        borderRadius: 100,
    },
    btn_login:{
        width:'100%',
        borderWidth: 1,
        borderRadius: 100,
        backgroundColor:btn_color,
        alignItems: 'center',
        justifyContent: 'center',
        height:40,
    },
    txt_login:{
        fontSize:btn_text_size,
        padding:5
    }
    
})

export default LoginForm