//colors
export const color_primary = '#03a9f4';
export const color_p_light = '#67daff';
export const color_p_dark = '#007ac1';
export const color_primary_text = '#000000';
export const color_p_dark_text = '#fff';

//fonts
export const font_size_large = 30;
export const font_size = 16;
export const font_size_small = 11;

