import React, { Component } from 'react';
import { View,Text } from 'react-native';

class Income extends Component{
    render(){
        return(
            <Text>Home</Text>
        )
    }
}

export default Income;